#!/usr/bin/env python
# -*- coding: UTF-8 -*-

from settings import config
import version
import time,os

class updater:
    def __init__(self):
        self.version = version.TWITTER_VERSION
        print self.version

    def check(self):
        pass

    def download(self):
        pass

    def backup(self):
        pass

    def setup(self):
        pass

    def server_version(self):
        pass